from django.apps import AppConfig


class CrawlingConfig(AppConfig):
    name = 'crawling'
