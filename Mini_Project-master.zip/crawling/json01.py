import json
# print(json1)
json1 = json.loads(text)
# print(type(json1), json1['result'])
# print(text.split(","))
list1 = []



# list1[0]
# print(list1[1]['cur_unit'])




print(list1)
# [{},{},{},{}]
